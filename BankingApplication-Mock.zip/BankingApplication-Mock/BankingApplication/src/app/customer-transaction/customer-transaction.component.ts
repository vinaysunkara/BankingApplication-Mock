import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService, TransactionTypeService } from '../customer.service';
import { ITransactionType } from 'src/app/Customer';

@Component({
  selector: 'app-customer-transaction',
  templateUrl: './customer-transaction.component.html',
  styleUrls: ['./customer-transaction.component.css'],
  providers: [TransactionTypeService]
})
export class CustomerTransactionComponent implements OnInit {
  // Account transaction list array.
  transactionType: ITransactionType[] = [];
  defaultType: any = null;
  transactionDone = false;

  angForm: FormGroup;
  customer: any = {};
  constructor(private route: ActivatedRoute, private router: Router,
              private fb: FormBuilder, private cs: CustomerService, private tt: TransactionTypeService) {
    this.createForm();
  }

  createForm() {
    this.angForm = this.fb.group({
      CustomerTransactionType: ['', Validators.required ],
      CustomerTransactionAmount: ['', Validators.required ]
    });
  }

  transactCustomer(CustomerTransactionType, CustomerTransactionAmount, CustomerId) {
    this.cs.transactCustomer(CustomerTransactionType, CustomerTransactionAmount, CustomerId);
    this.transactionDone = true;
  }

  ngOnInit() {
    this.transactionType = this.tt.getTransactionType();
    this.route.params.subscribe(params => {
      this.cs.editCustomer(params.id).subscribe(res => {
        this.customer = res;
    });
  });
  }
}
