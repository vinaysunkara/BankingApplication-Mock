export default class Customer {
  CustomerName: string;
  CustomerAccountType: string;
  CustomerAccountStatus: number;
}


// type Interface.
export interface IAccountType {
  id: number;
  title: string;
}

// status Interface.
export interface IAccountStatus {
  id: number;
  title: string;
}

// transaction Interface.
export interface ITransactionType {
  id: number;
  title: string;
}
