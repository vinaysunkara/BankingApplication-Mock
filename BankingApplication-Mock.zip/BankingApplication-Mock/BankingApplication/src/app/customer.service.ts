import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IAccountStatus, IAccountType, ITransactionType } from './Customer';
import { retry, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  uri = 'http://localhost:8080/api/v1';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }

  addCustomer(CustomerName, CustomerAccountStatus, CustomerAccountType, CustomerTransactionAmount) {
    console.log(CustomerName, CustomerAccountStatus, CustomerAccountType, CustomerTransactionAmount);
    const obj = {
      email: '',
      accountType: CustomerAccountType,
      accountStatus: CustomerAccountStatus,
      name: CustomerName,
      amount: CustomerTransactionAmount
    };
    this.http.post(`${this.uri}/createCustomer`, obj, this.httpOptions)
    .subscribe(res => console.log('Done'));
  }
  transactCustomer(CustomerTransactionType, CustomerTransactionAmount, CustomerId) {
    console.log(CustomerTransactionType, CustomerTransactionAmount, CustomerId);
    const obj = {
      id: CustomerId,
      transType: CustomerTransactionType,
      amt: CustomerTransactionAmount,
    };
    this.http.post(`${this.uri}/deposit/${CustomerId}`, obj, this.httpOptions)
    .subscribe(res => console.log('Done'));
  }
  getCustomers() {
    return this
           .http
           .get(`${this.uri}/customers`);
  }

  editCustomer(id) {
    return this
            .http
            .get(`${this.uri}/customerById/${id}`);
  }

  updateCustomer(CustomerName, CustomerAccountStatus, CustomerAccountType, id) {
    const obj = {
      email: '',
      accountType: CustomerAccountType,
      accountStatus: CustomerAccountStatus,
      name: CustomerName
    };
    this
      .http
      .put(`${this.uri}/updateCustomer/${id}`, obj)
      .subscribe(res => console.log('Update Complete'));
  }
}
@Injectable()
export class AccountStatusService {
  accountStatus: IAccountStatus[] = [];

    // Get Ratings.
    getAccountStatus() {
       return this.accountStatus = [
            {id: 1, title: 'Active'},
            {id: 2, title: 'Closed'},
        ];
    }
}

@Injectable()
export class AccountTypeService {
  accountType: IAccountType[] = [];

    // Get Ratings.
    getAccountType() {
       return this.accountType = [
            {id: 1, title: 'Saving'},
            {id: 2, title: 'Current'},
        ];
    }
}
@Injectable()
export class TransactionTypeService {
  transactionType: ITransactionType[] = [];

    // Get Ratings.
    getTransactionType() {
       return this.transactionType = [
            {id: 1, title: 'Deposit'},
            {id: 2, title: 'Withdraw'},
        ];
    }
}

