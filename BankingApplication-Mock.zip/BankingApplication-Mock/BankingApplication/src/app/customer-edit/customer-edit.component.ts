import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService, AccountStatusService, AccountTypeService } from '../customer.service';
import { IAccountStatus, IAccountType } from 'src/app/Customer';

@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrls: ['./customer-edit.component.css'],
  providers: [AccountStatusService, AccountTypeService]
})
export class CustomerEditComponent implements OnInit {

  angForm: FormGroup;
  customer: any = {};
    // Account status list array.
    accountStatus: IAccountStatus[] = [];
    accountType: IAccountType[] = [];

  constructor(private route: ActivatedRoute, private router: Router, private cs: CustomerService, private fb: FormBuilder,
              private as: AccountStatusService, private at: AccountTypeService) {
      this.createForm();
 }

  createForm() {
    this.angForm = this.fb.group({
      CustomerName: ['', Validators.required ],
      CustomerAccountType: ['', Validators.required ],
      CustomerAccountStatus: ['', Validators.required ]
    });
  }

  ngOnInit() {
    this.accountStatus = this.as.getAccountStatus();
    this.accountType = this.at.getAccountType();
    this.route.params.subscribe(params => {
        this.cs.editCustomer(params.id).subscribe(res => {
          this.customer = res;
      });
    });
  }

  updateCustomer(CustomerName, CustomerAccountStatus, CustomerAccountType, id) {
    this.route.params.subscribe(params => {
      this.cs.updateCustomer(CustomerName, CustomerAccountStatus, CustomerAccountType, params.id);
      // Here is the other part of the trick
      setTimeout(() => {
        this.router.navigated = false;
        this.router.navigate(['customers']);
      }, 500);
    });
  }
}
