import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CustomerService, AccountStatusService, AccountTypeService } from '../customer.service';
import { IAccountStatus, IAccountType } from 'src/app/Customer';

@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.css'],
  providers: [AccountStatusService, AccountTypeService]
})
export class CustomerAddComponent implements OnInit {
  // Account status list array.
  accountStatus: IAccountStatus[] = [];
  defaultStatus: any = null;
  accountType: IAccountType[] = [];
  defaultType: any = null;
  customerCreated = false;

  angForm: FormGroup;
  constructor(private fb: FormBuilder, private cs: CustomerService, private as: AccountStatusService, private at: AccountTypeService) {
    this.createForm();
  }

  createForm() {
    this.angForm = this.fb.group({
      CustomerName: ['', Validators.required ],
      CustomerAccountType: ['', Validators.required ],
      CustomerAccountStatus: ['', Validators.required ],
      CustomerTransactionAmount: ['', Validators.required ]
    });
  }

  addCustomer(CustomerName, CustomerAccountStatus, CustomerAccountType, CustomerTransactionAmount) {
    this.cs.addCustomer(CustomerName, CustomerAccountStatus, CustomerAccountType, CustomerTransactionAmount);
    this.customerCreated = true;
  }

  ngOnInit() {
    this.accountStatus = this.as.getAccountStatus();
    this.accountType = this.at.getAccountType();
  }

}
