package com.bank.transactions.BankingTransaction.DAO;

import java.util.List;

import com.bank.transactions.BankingTransaction.entity.Customer;
import com.bank.transactions.BankingTransaction.entity.Transactions;
import com.bank.transactions.BankingTransaction.model.Customers;

/**
 * @author vinay babu sunkara
 *
 */
public interface CustomerDao {

	public List<Customers> getAllCustomers();

	public void save(Customer cust);

	public void update(int id, Customer cust);

	public void deposit(int id, Transactions trans);

	public Customers getCustomer(int id);
}
