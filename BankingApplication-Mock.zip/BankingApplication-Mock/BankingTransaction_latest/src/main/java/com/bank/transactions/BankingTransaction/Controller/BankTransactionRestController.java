package com.bank.transactions.BankingTransaction.Controller;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.transactions.BankingTransaction.Exception.CustomerNotFoundException;
import com.bank.transactions.BankingTransaction.entity.Customer;
import com.bank.transactions.BankingTransaction.entity.Transactions;
import com.bank.transactions.BankingTransaction.model.Customers;
import com.bank.transactions.BankingTransaction.service.CustomerService;

/**
 * @author vinay babu sunkara
 *
 */
/**
 * @author User
 *
 */
@RestController
@RequestMapping("/api/v1")
public class BankTransactionRestController {

	public CustomerService customerService;

	@Autowired
	public BankTransactionRestController(CustomerService theCustomerService) {
		customerService = theCustomerService;
	}

	// GET LIST OF CUSTOMERS
	/**
	 * @return
	 */
	@GetMapping("/customers")
	@CrossOrigin(origins = "*")
	public List<Customers> getAllCustomers() {
		return customerService.getAllCustomers();
	}

	// CREATE CUSTOMER
	/**
	 * @param cust
	 */
	@PostMapping("/createCustomer")
	@CrossOrigin(origins = "*")
	public void save(@RequestBody Customer cust) {

		Random r = new Random(System.currentTimeMillis());
		Long AccNum = 1000000000l + r.nextInt(2000000000);
		String AccountNumber = Long.toString(AccNum);
		cust.setAccountNum(AccountNumber);
		customerService.save(cust);
	}

	// UPDATE EXISTING CUSTOMER
	/**
	 * @param id
	 * @param cust
	 * @return
	 */
	@CrossOrigin(origins = "*")
	@PutMapping("/updateCustomer/{id}")
	public String updateCustomer(@PathVariable("id") int id, @RequestBody Customer cust) {

		if (id <= 0) {
			throw new CustomerNotFoundException("CustomerId not found " + id);
		}

		customerService.updateCustomer(id, cust);

		return "customer has been updated successfully";

	}
	
	// GET CUSTOMER by id
	@CrossOrigin(origins = "*")
	@GetMapping("/customerById/{id}")
	public Customers getCustomer(@PathVariable("id") int id) {
		return customerService.getCustomer(id);
	}


	// DEPOSIT AND WITHDRAW MONEY
	/**
	 * @param id
	 * @param trans
	 * @return
	 */
	@CrossOrigin(origins = "*")
	@PostMapping("/deposit/{id}")
	public String deposit(@PathVariable("id") int id, @RequestBody Transactions trans) {

		if (id <= 0) {
			throw new CustomerNotFoundException("CustomerId not found " + id);
		}
		customerService.deposit(id, trans);

		return "Amount deposited successfully";
	}

}
