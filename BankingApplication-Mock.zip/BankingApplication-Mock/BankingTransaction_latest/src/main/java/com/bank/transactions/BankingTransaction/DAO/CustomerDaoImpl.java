package com.bank.transactions.BankingTransaction.DAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bank.transactions.BankingTransaction.entity.Customer;
import com.bank.transactions.BankingTransaction.entity.Transactions;
import com.bank.transactions.BankingTransaction.model.Customers;

/**
 * @author vinay babu sunkara
 *
 */

@Repository
public class CustomerDaoImpl implements CustomerDao {

	EntityManager entityManager;

	@Autowired
	public CustomerDaoImpl(EntityManager theEntityManager) {
		entityManager = theEntityManager;
	}

	@Override
	public List<Customers> getAllCustomers() {

		Session session = entityManager.unwrap(Session.class);

		Query<Customer> custQuery = session.createQuery("from Customer",Customer.class);

		List<Customer> listCust = custQuery.getResultList();
		
		List<Customers> al = new ArrayList<Customers> ();
			
		for(Customer  list:listCust)
		{
			Customers cu = new Customers();
			
			cu.setAccountNum(list.getAccountNum());
			cu.setAccountStatus(list.getAccountStatus());
			cu.setId(list.getId());
			cu.setAmount(list.getAmount());
			cu.setName(list.getName());
			cu.setAccountType(list.getAccountType());
			cu.setEmail(list.getEmail());
			al.add(cu);
		}
		
		return al;
	}

	@Override
	public void save(Customer cust) {
		Session session = entityManager.unwrap(Session.class);
		session.saveOrUpdate(cust);
	}

	@Override
	public void update(int id, Customer cust) {

		Session session = entityManager.unwrap(Session.class);
		Customer theCus = session.byId(Customer.class).load(id);
		theCus.setAccountType(cust.getAccountType());
		theCus.setAccountStatus(cust.getAccountStatus());
		theCus.setName(cust.getName());
		theCus.setEmail(cust.getEmail());
		session.flush();

	}


	@Override
	public Customers getCustomer(int id) {
		// TODO Auto-generated method stub
		Session session = entityManager.unwrap(Session.class);
		Customer theCus = session.get(Customer.class, id);
		
		Customers cu = new Customers();
		
		cu.setAccountNum(theCus.getAccountNum());
		cu.setAccountStatus(theCus.getAccountStatus());
		cu.setId(theCus.getId());
		cu.setAmount(theCus.getAmount());
		cu.setName(theCus.getName());
		cu.setAccountType(theCus.getAccountType());
		cu.setEmail(theCus.getEmail());
		
		return cu;
		
	}

	@Override
	public void deposit(int id, Transactions trans) {

		Session session = entityManager.unwrap(Session.class);
		Customer custt = session.get(Customer.class, id);
		double totalAmount;
		double DepositAmount;
		Transactions mycust = new Transactions();
		if (trans.getTransType().equalsIgnoreCase("Deposit")) {
			if (custt.getAmount() != 0.0) {
				DepositAmount = trans.getAmt();
				totalAmount = DepositAmount + custt.getAmount();
				custt.setAmount(totalAmount);
				session.saveOrUpdate(custt);

				mycust.setAmt(trans.getAmt());
				mycust.setTransTimestamp(new Date());
				mycust.setTransType(trans.getTransType());
			}

		}

		if (trans.getTransType().equalsIgnoreCase("Withdraw")) {

			if (custt.getAmount() != 0.0) {
				double withdrawAmount = trans.getAmt();
				totalAmount = custt.getAmount() - withdrawAmount;
				custt.setAmount(totalAmount);
				session.saveOrUpdate(custt);

				mycust.setAmt(trans.getAmt());
				mycust.setTransTimestamp(new Date());
				mycust.setTransType(trans.getTransType());
			}

		}
		mycust.setCustomer(custt);
		session.save(mycust);
	}

}
