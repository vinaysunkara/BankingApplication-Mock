package com.bank.transactions.BankingTransaction.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Entity
@Table(name ="CUSTOMER")
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
    private Integer id;

    @Column(name = "NAME")
    private String Name;
    
    @Column(name = "EMAIL")
    private String email;
    
    @Column(name = "ACC_NUM")
    private String accountNum;
    
    @Column(name = "ACC_TYPE")
    private String accountType;
    
    @Column(name = "ACC_STATUS")
    private String accountStatus;
    
    @Column(name = "AMOUNT")
    private double amount;
    
    @OneToMany(mappedBy="customer",cascade= {CascadeType.PERSIST,CascadeType.MERGE,CascadeType.DETACH,CascadeType.REFRESH})
    private List<Transactions> transactions;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	

	public List<Transactions> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transactions> transactions) {
		this.transactions = transactions;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", Name=" + Name + ", email=" + email + ", accountNum=" + accountNum
				+ ", accountType=" + accountType + ", accountStatus=" + accountStatus + "]";
	}

	public Customer(Integer id, String name, String email, String accountNum, String accountType,
			String accountStatus) {
		this.id = id;
		Name = name;
		this.email = email;
		this.accountNum = accountNum;
		this.accountType = accountType;
		this.accountStatus = accountStatus;
	}
    
	
	public Customer()
	{
		
	}
	
    
    
}
