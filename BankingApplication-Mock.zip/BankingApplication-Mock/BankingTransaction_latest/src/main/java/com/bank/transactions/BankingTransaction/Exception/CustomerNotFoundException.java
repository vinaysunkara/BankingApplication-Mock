package com.bank.transactions.BankingTransaction.Exception;

/**
 * @author vinay babu sunkara
 *
 */
public class CustomerNotFoundException extends RuntimeException {
	
	public CustomerNotFoundException(String message)
	{
		super(message);
	}

}
