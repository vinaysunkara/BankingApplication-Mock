package com.bank.transactions.BankingTransaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author vinay babu sunkara
 *
 */
@SpringBootApplication
public class BankingTransactionApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingTransactionApplication.class, args);
	}

}
