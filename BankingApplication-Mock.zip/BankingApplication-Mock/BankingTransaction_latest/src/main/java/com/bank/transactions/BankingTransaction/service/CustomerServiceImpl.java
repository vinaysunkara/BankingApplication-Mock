package com.bank.transactions.BankingTransaction.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.transactions.BankingTransaction.DAO.CustomerDao;
import com.bank.transactions.BankingTransaction.entity.Customer;
import com.bank.transactions.BankingTransaction.entity.Transactions;
import com.bank.transactions.BankingTransaction.model.Customers;

@Service
public class CustomerServiceImpl implements CustomerService {

	CustomerDao customerDao;
	
	@Autowired
	public CustomerServiceImpl(CustomerDao theCustomerDao)
	{
		customerDao=theCustomerDao;
	}
	
	
	@Override
	@Transactional
	public List<Customers> getAllCustomers() {
		List<Customers> cust = customerDao.getAllCustomers();
		return cust;
	}

	
	@Override
	@Transactional
	public void save(Customer cust) {
		customerDao.save(cust);
	}


	@Override
	@Transactional
	public void updateCustomer(int id,Customer cust) {
		// TODO Auto-generated method stub
		customerDao.update(id ,cust);
		
	}
	
	@Override
	@Transactional
	public Customers getCustomer(int id) {
		// TODO Auto-generated method stub
	return	customerDao.getCustomer(id);
		}

	@Override
	@Transactional
	public void deposit(int id, Transactions trans) {
		// TODO Auto-generated method stub
		customerDao.deposit(id,trans);
	}

}
