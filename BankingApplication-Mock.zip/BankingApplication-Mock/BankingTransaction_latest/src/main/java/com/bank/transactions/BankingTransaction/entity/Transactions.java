package com.bank.transactions.BankingTransaction.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name ="TRANSACTIONS")
public class Transactions {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "TRANS_ID")
    private Integer transId;
	
	//@Column(name = "CUSTOMER_ID")
    //private Integer customerId;

    
    
    @Column(name = "DEPOSIT_AMT")
    private double amt;
    
    @ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.MERGE,
    		CascadeType.DETACH,CascadeType.REFRESH})
    @JoinColumn(name="CUSTOMER_ID")
    private Customer customer;
    
    @Column(name = "WITHDRAW_AMT")
    private double Amt;
    
    @Column(name = "TRANS_TIMESTAMP")
    private Date transTimestamp;
    
    @Column(name = "TRANS_TYPE")
    private String transType;

	public Integer getTransId() {
		return transId;
	}

	public void setTransId(Integer transId) {
		this.transId = transId;
	}

	/*public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}*/

	public double getAmt() {
		return amt;
	}

	public void setAmt(double amt) {
		this.amt = amt;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	/*public double getWithdrawAmt() {
		return withdrawAmt;
	}

	public void setWithdrawAmt(double withdrawAmt) {
		this.withdrawAmt = withdrawAmt;
	}*/
	
	public Date getTransTimestamp() {
		return transTimestamp;
	}

	public void setTransTimestamp(Date transTimestamp) {
		this.transTimestamp = transTimestamp;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public Transactions(double amt, Customer customer, Date transTimestamp,
			String transType) {
		
		this.amt = amt;
		this.customer = customer;
		//this.withdrawAmt = withdrawAmt;
		this.transTimestamp = transTimestamp;
		this.transType = transType;
	}

	@Override
	public String toString() {
		return "Transactions [transId=" + transId + ", amt=" + amt + ", customer="
				+ customer + ", transTimestamp=" + transTimestamp + ", transType="
				+ transType + "]";
	}

	public Transactions()
	{
		
	}
	
	
    
}
