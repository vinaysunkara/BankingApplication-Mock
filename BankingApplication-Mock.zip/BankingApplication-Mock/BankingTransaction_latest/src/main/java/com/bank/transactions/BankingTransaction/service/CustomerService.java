package com.bank.transactions.BankingTransaction.service;

import java.util.List;

import com.bank.transactions.BankingTransaction.entity.Customer;
import com.bank.transactions.BankingTransaction.entity.Transactions;
import com.bank.transactions.BankingTransaction.model.Customers;

public interface CustomerService {
	
	public List<Customers> getAllCustomers();

	public void save(Customer cust);

	public void  updateCustomer(int id,Customer cust);

	public void deposit(int id, Transactions trans);

	public Customers getCustomer(int id);

}
