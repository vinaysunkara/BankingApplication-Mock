package com.bank.transactions.BankingTransaction.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * @author vinay babu sunkara
 *
 */
@ControllerAdvice
public class CustomerRestExceptionHandler {

	@ExceptionHandler
	public ResponseEntity<CustomerErrorResponse> handleException(CustomerNotFoundException msg) {

		CustomerErrorResponse err = new CustomerErrorResponse();
		err.setStatusCode(HttpStatus.NOT_FOUND.value());
		err.setMessage(msg.getMessage());
		err.setTimestamp(System.currentTimeMillis());

		return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);

	}

	@ExceptionHandler
	public ResponseEntity<CustomerErrorResponse> handleException(Exception msg) {

		CustomerErrorResponse err = new CustomerErrorResponse();
		err.setStatusCode(HttpStatus.BAD_REQUEST.value());
		err.setMessage(msg.getMessage());
		err.setTimestamp(System.currentTimeMillis());

		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);

	}

}
